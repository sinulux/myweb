CREATE VIEW v_formdef_template AS
  (SELECT
     `b`.`SUBJECT`        AS `SUBJECT`,
     `b`.`FORMDEFID`      AS `FORMDEFID`,
     `a`.`CONDITIONFIELD` AS `CONDITIONFIELD`,
     `b`.`FORMKEY`        AS `FORMKEY`
   FROM (`bpm`.`bpm_data_template` `a`
     JOIN `bpm`.`bpm_form_def` `b`)
   WHERE ((`a`.`FORMKEY` = `b`.`FORMKEY`) AND (`b`.`ISDEFAULT` = 1)));
